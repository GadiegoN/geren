import { CadastroAluno } from "./componets/cadastro-aluno";
import { Menu } from "./componets/menu";

export function App() {
  return (
    <div>
      <Menu />
    </div>
  )
}
